---
name: "eberick-relatorio-avaliacao-do-projeto"
description: "Gera o relatório formal de Avaliação Técnica de Projeto (ATP) estrutural em Word, a partir do projeto aberto no AltoQi Eberick pelo MCP: identificação, critérios, estabilidade global, integridade do modelo, consumo de materiais, diagnóstico e parecer final (aprovado, aprovado com ressalvas ou reprovado). Só leitura no Eberick; gera .docx. Use quando o usuário pedir \"relatório ATP\", \"avaliação técnica de projeto\", \"emitir a ATP\", \"documento de avaliação técnica do projeto estrutural\", \"parecer técnico do projeto para o cliente\" ou variações. Para revisão técnica interna em HTML use eberick-agente-revisao; para checklist normativo use eberick-checklist-conformidade."
---

# Relatório ATP (Eberick)

Documento formal, com parecer. Só leitura no Eberick.

## Como coletar os dados do Eberick (MCP 2026-11)

- **Sessão primeiro:** `projects-list_sessions` → `sessionId`, exigido por todas as ferramentas. Mais de uma sessão aberta → pergunte qual projeto. Nenhuma → peça para abrir o projeto no Eberick.
- **Caixa de diálogo aberta bloqueia o MCP.** Se a resposta for "The main window is blocked by a modal dialog", peça para fechar a janela aberta no Eberick e tente de novo.
- **Projeto processado.** Se um relatório disser que o componente não está disponível, peça para processar a estrutura e pare.
- **Formato:** os relatórios voltam como texto com tabelas (markdown), nas unidades configuradas no Eberick (em geral kgf/cm², tf, kgf.m). Leia os valores das tabelas; não espere JSON nem HTML.
- **Pavimento** é o número do "Lance" devolvido por `eberick-get_floors` ("1", "2"...), sem zero à esquerda.
- **Memorial de cálculo** (`eberick-get_report_full_calculation`) só com filtros `element_type`, `report_type` e, quando couber, `floor`. Sem filtros ele gera o memorial inteiro e é lento.

- **Comando assíncrono:** se uma chamada devolver referência de comando em vez do conteúdo, consulte `mcp-get_command_status` até concluir. Não trate como falha.
- **Sessão "ativa" pode estar expirada.** Se vier "Session not found or expired", chame `projects-list_sessions` de novo; se persistir, peça para reabrir o projeto e reiniciar o servidor MCP no Eberick (Colaboração > Servidor MCP > Iniciar).


## Etapa 1 — Identificação

Pergunte ao usuário o que não vem do Eberick: nome da obra, contratante, responsável técnico pelo projeto, avaliador, número do relatório e data. O que ele não informar fica "[A preencher]" no documento.

## Etapa 2 — Coletar

1. `project-get_data`, `eberick-get_floors`.
2. `eberick-get_report_project_criteria` → normas, materiais, cobrimentos, ações (é longo: extraia só o necessário para a seção 3).
3. `eberick-get_report_gamma_z_stability_verification`, `eberick-get_report_p_delta_analysis`, `eberick-get_report_global_imperfections` → estabilidade.
4. `eberick-get_report_adopted_combinations` → combinações.
5. `eberick-get_report_analysis_messages` → erros e avisos.
6. `eberick-get_report_structure_diagnostics` → consumos, flechas e indicadores.
7. `eberick-get_report_horizontal_wind_displacements` → deslocamentos.

## Etapa 3 — Analisar

Use `references/criterios-avaliacao.md` para limites e critérios e `references/normas-abnt.md` para as citações. Classifique cada seção em conforme, atenção ou não conforme. Parecer final:
- **Aprovado:** nenhuma não conformidade.
- **Aprovado com ressalvas:** só itens de atenção, ou não conformidades de ELS que não comprometem a segurança.
- **Reprovado:** qualquer não conformidade de ELU, estabilidade (γz acima de 1,30) ou erro de análise não resolvido.

## Etapa 4 — Gerar o Word

Leia a skill de documentos Word (docx) do ambiente antes de gerar. Siga a estrutura de `references/template-atp.md`: folha de rosto, identificação, critérios, estabilidade global, integridade do modelo, consumo de materiais, diagnóstico, conclusão e parecer, assinaturas. Use tabelas para os números, cores de parecer (verde, laranja, vermelho) e sumário. Nome do arquivo: `relatorio-atp-<obra>-<AAAA-MM-DD>.docx`.

Apresente o arquivo e um resumo do parecer com os dois ou três fundamentos principais.
