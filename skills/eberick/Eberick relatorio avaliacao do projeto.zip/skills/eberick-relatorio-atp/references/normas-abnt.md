# Normas ABNT de Referência — ATP Estrutural

## Normas Principais

### ABNT NBR 6118:2023
**Projeto de estruturas de concreto — Procedimento**
- Norma base para projeto estrutural de concreto armado e protendido
- Capítulos relevantes para ATP:
  - Cap. 11: Ações (combinações de ações)
  - Cap. 12: Métodos de análise estrutural
  - Cap. 13: Critérios especiais de análise e projeto
  - Cap. 15: Estabilidade global e efeitos de 2ª ordem (γz, P-Delta)
  - Cap. 17: Dimensionamento de elementos lineares
  - Cap. 18: Dimensionamento de lajes
  - Cap. 23: Estados limites de serviço (deformações, fissuras)

### ABNT NBR 6120:2019
**Ações para o cálculo de estruturas de edificações**
- Cargas de uso por tipo de ocupação
- Ações permanentes e variáveis

### ABNT NBR 6122:2022
**Projeto e execução de fundações**
- Verificar compatibilidade com fundações (quando aplicável)

### ABNT NBR 8681:2003
**Ações e segurança nas estruturas — Procedimento**
- Coeficientes de ponderação das ações (γf)
- Coeficientes de ponderação da resistência (γs, γc)
- Combinações normais e especiais

### ABNT NBR 15200:2012
**Projeto de estruturas de concreto em situação de incêndio**
- Verificar se TRRF foi considerado (quando aplicável)

---

## Normas Complementares

| Norma | Título | Aplicação |
|-------|--------|-----------|
| NBR 6118:2023 item 6.2 | Classes de agressividade ambiental | Cobrimento e durabilidade |
| NBR 6118:2023 item 7.3 | Resistência do concreto | Fck mínimo por CAA |
| NBR 6118:2023 item 14.6 | Desvios de execução | Tolerâncias geométricas |
| NBR 6118:2023 item 17.3 | Pilares — efeitos locais de 2ª ordem | Índice de esbeltez λ |
| NBR 6118:2023 item 18.3 | Lajes — verificações de ELS | Deformação e fissuração |
| NBR 6118:2023 item 20 | Verificação ao puncionamento | Lajes sobre pilares |
| NBR 6118:2023 item 22 | Ligações | Nós de pórtico e juntas |
| NBR 7190:2022 | Projeto de estruturas de madeira | Se houver elementos mistos |
| NBR 6355:2012 | Perfis estruturais de aço | Se houver elementos mistos |

---

## Critérios Normativos Chave para ATP

### Estabilidade Global (NBR 6118:2023 — item 15.5.3)

| Classificação | Condição | Ação |
|---|---|---|
| Nós fixos | γz ≤ 1,10 | Efeitos de 2ª ordem globais desprezíveis |
| Nós móveis | 1,10 < γz ≤ 1,30 | Majorar esforços de 1ª ordem por γz |
| Instável | γz > 1,30 | Projeto não aceito — revisão obrigatória |

### Cobrimento Nominal (NBR 6118:2023 — item 7.4.7.5)

| CAA | Laje | Viga/Pilar | Pilar externo |
|-----|------|------------|---------------|
| I | 15 mm | 20 mm | 25 mm |
| II | 20 mm | 25 mm | 30 mm |
| III | 25 mm | 30 mm | 40 mm |
| IV | 30 mm | 40 mm | 50 mm |

### Resistência mínima do concreto (NBR 6118:2023 — item 8.2.5)

| CAA | fck mínimo |
|-----|-----------|
| I | 20 MPa |
| II | 25 MPa |
| III | 30 MPa |
| IV | 40 MPa |

### Coeficientes de ponderação das ações (NBR 8681:2003)

| Tipo de ação | γf1 | γf3 | γf = γf1 × γf3 |
|---|---|---|---|
| Ações permanentes de grande variabilidade | 1,4 | 1,2 | 1,68 |
| Ações permanentes de pequena variabilidade | 1,4 | 1,0 | 1,40 |
| Ações variáveis | 1,4 | 1,4 | 1,96 → arredondado 1,4 (ELU normal) |

### Combinações de ações (NBR 6118:2023 — item 11.7)

**ELU Normal:**
Fd = γg × Fgk + γq × (Fq1k + Σψ0j × Fqjk)

**ELS:**
Fd,ser = Fgk + Σψ1j × Fqjk (combinação frequente)
Fd,ser = Fgk + Σψ2j × Fqjk (combinação quase-permanente)

---

## Limites de Verificação em ELS

### Deslocamentos excessivos (NBR 6118:2023 — item 13.3)

| Tipo | Limite |
|------|--------|
| Vigas e lajes — uso geral | l/250 |
| Vigas e lajes — aparência | l/350 |
| Pisos com paredes frágeis | l/500 |
| Deslocamento horizontal de pavimento | h/400 |
| Deslocamento horizontal total | H/1700 |

### Abertura de fissuras (NBR 6118:2023 — item 13.4)

| CAA | wk,lim (tração simples ou flexão) |
|-----|-----------------------------------|
| I | 0,4 mm |
| II | 0,3 mm |
| III e IV | 0,2 mm |
