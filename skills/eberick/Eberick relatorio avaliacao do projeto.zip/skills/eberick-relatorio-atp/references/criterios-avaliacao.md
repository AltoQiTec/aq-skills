# Critérios de Avaliação ATP — Limites e Classificações

## Metodologia de Avaliação

A ATP classifica cada domínio avaliado em três categorias:

| Status | Símbolo | Critério |
|--------|---------|---------|
| Conforme | ✅ | Todos os indicadores dentro dos limites normativos |
| Atenção | ⚠️ | Indicadores em zona de alerta ou com ressalvas pontuais |
| Não Conforme | ❌ | Um ou mais indicadores violam limites normativos obrigatórios |

---

## Critérios por Domínio

### 1. Estabilidade Global

| Indicador | ✅ Conforme | ⚠️ Atenção | ❌ Não Conforme |
|-----------|------------|-----------|----------------|
| γz (nós fixos) | ≤ 1,10 | — | > 1,10 sem considerar 2ª ordem |
| γz (nós móveis) | 1,10 < γz ≤ 1,30 com 2ª ordem considerada | γz entre 1,20–1,30 | > 1,30 |
| P-Delta amplificação | < 10% | 10–30% | > 30% |
| Deslocamento horizontal total | ≤ H/1700 | H/1700 < δ ≤ H/850 | > H/850 |

**Peso na avaliação global:** ALTO — um resultado ❌ aqui leva ao parecer REPROVADO.

---

### 2. Integridade do Modelo Computacional

| Indicador | ✅ Conforme | ⚠️ Atenção | ❌ Não Conforme |
|-----------|------------|-----------|----------------|
| Erros críticos de processamento | 0 erros | — | ≥ 1 erro crítico |
| Avisos de desequilíbrio de forças | Ausentes | Presentes e justificados | Presentes sem justificativa |
| Avisos de elementos sobrepostos | Ausentes | ≤ 2 elementos | > 2 elementos |
| Processamento concluído | Sim | Sim com ressalvas | Não concluído |
| Consistência do modelo | Convergência total | Convergência parcial | Não convergiu |

**Peso na avaliação global:** ALTO — erros críticos levam ao parecer REPROVADO.

---

### 3. Eficiência e Consumo de Materiais

#### Consumo específico de aço (kg/m³ de concreto)

| Tipologia | ✅ Eficiente | ⚠️ Elevado | ❌ Muito Elevado |
|-----------|-------------|-----------|----------------|
| Lajes maciças | 60–100 kg/m³ | 100–150 kg/m³ | > 150 kg/m³ |
| Vigas | 100–180 kg/m³ | 180–250 kg/m³ | > 250 kg/m³ |
| Pilares | 100–160 kg/m³ | 160–220 kg/m³ | > 220 kg/m³ |
| Geral (média ponderada) | 80–150 kg/m³ | 150–200 kg/m³ | > 200 kg/m³ |

> **Atenção**: Consumo abaixo do mínimo também pode indicar subestruturação — verificar nesse caso.
> Valores de referência para concreto armado moldado in loco em edifícios convencionais.

#### Consumo de concreto

| Indicador | Avaliação |
|-----------|-----------|
| Uniformidade por pavimento | Variações > 30% entre pavimentos similares merecem investigação |
| Coerência com o sistema estrutural | Verificar se volumes são compatíveis com o sistema adotado |

**Peso na avaliação global:** MÉDIO — valores atípicos geram ⚠️ mas não levam automaticamente a REPROVADO.

---

### 4. Diagnóstico Estrutural (Eberick)

| Indicador | ✅ Conforme | ⚠️ Atenção | ❌ Não Conforme |
|-----------|------------|-----------|----------------|
| Status geral do diagnóstico | Aprovado | Aprovado com ressalvas | Reprovado |
| Elementos em estado crítico | Nenhum | 1–3 elementos | > 3 ou elemento principal |
| Itens de revisão obrigatória | Nenhum | Pontuais, não estruturais | Estruturais/globais |
| Pontos críticos identificados | Ausentes | Presentes e tratáveis | Comprometem segurança |

**Peso na avaliação global:** ALTO.

---

## Matriz de Parecer Final

| Estabilidade | Integridade | Diagnóstico | Parecer Final |
|---|---|---|---|
| ✅ | ✅ | ✅ | ✅ APROVADO |
| ✅ | ✅ | ⚠️ | ⚠️ APROVADO COM RESSALVAS |
| ✅ | ⚠️ | ✅ | ⚠️ APROVADO COM RESSALVAS |
| ⚠️ | ✅ | ✅ | ⚠️ APROVADO COM RESSALVAS |
| ✅ | ✅ | ❌ | ❌ REPROVADO |
| ✅ | ❌ | qualquer | ❌ REPROVADO |
| ❌ | qualquer | qualquer | ❌ REPROVADO |
| ⚠️ | ⚠️ | ⚠️ | ⚠️ APROVADO COM RESSALVAS |
| ⚠️ | ⚠️ | ❌ | ❌ REPROVADO |

> **Regra geral**: qualquer ❌ em qualquer domínio principal (Estabilidade, Integridade, Diagnóstico) resulta em parecer **REPROVADO**.
> Múltiplos ⚠️ podem resultar em APROVADO COM RESSALVAS, desde que nenhum seja ❌.
> Eficiência de materiais sozinha não repova — gera ressalvas mesmo que ❌.

---

## Checklist de Verificação do Revisor

Use este checklist para garantir completude da avaliação antes de emitir o parecer:

### Dados e Documentação
- [ ] Dados de identificação da obra coletados
- [ ] Engenheiros responsáveis identificados com CREA e ART
- [ ] Data e revisão do projeto registrada
- [ ] Normas aplicáveis listadas

### Parâmetros do Projeto
- [ ] Sistema estrutural identificado
- [ ] Número de pavimentos e altura total registrados
- [ ] fck verificado em relação à CAA
- [ ] Cobrimento nominal verificado em relação à CAA
- [ ] Critérios de modelagem descritos

### Estabilidade Global
- [ ] γz calculado para direções X e Y
- [ ] Combinações governantes identificadas
- [ ] Classificação da estrutura (nós fixos / nós móveis) definida
- [ ] Consideração de 2ª ordem verificada se necessário
- [ ] Deslocamentos horizontais avaliados (P-Delta)

### Integridade do Modelo
- [ ] Processamento concluído sem erros críticos
- [ ] Todos os erros registrados e avaliados
- [ ] Todos os avisos relevantes analisados
- [ ] Impacto na confiabilidade dos resultados avaliado

### Eficiência de Materiais
- [ ] Consumo específico de aço calculado
- [ ] Comparação com valores de referência realizada
- [ ] Elementos ou pavimentos atípicos identificados
- [ ] Volume de concreto por tipologia avaliado

### Diagnóstico
- [ ] Pontos críticos do Eberick registrados
- [ ] Elementos com problemas identificados
- [ ] Status de aprovação do Eberick registrado
- [ ] Recomendações formuladas por item

### Parecer
- [ ] Domínios avaliados individualmente
- [ ] Matriz de parecer aplicada
- [ ] Fundamentação normativa citada
- [ ] Ressalvas priorizadas (Alta / Média / Baixa)
- [ ] Limitações da avaliação declaradas
