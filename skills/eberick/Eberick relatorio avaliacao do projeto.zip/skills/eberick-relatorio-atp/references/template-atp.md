# Template Detalhado — Relatório ATP

## 1. FOLHA DE ROSTO

### Conteúdo da capa (sem numeração de página)

```
[Logotipo da empresa — placeholder se não disponível]

RELATÓRIO DE AVALIAÇÃO TÉCNICA DE PROJETO
ESTRUTURAS DE CONCRETO ARMADO

Obra: [NOME DA OBRA]
Endereço: [ENDEREÇO]

Número do Relatório: ATP-[YYYY]-[NNN]
Data: [DD/MM/YYYY]
Revisão: [00]

Engenheiro Responsável pelo Projeto: [NOME] — CREA [NÚMERO]
Engenheiro Responsável pela ATP: [NOME] — CREA [NÚMERO]
ART de Projeto: [NÚMERO]
```

Centralizado verticalmente na página. Separar blocos com linhas horizontais (border bottom em Paragraph).

---

## 2. IDENTIFICAÇÃO DO PROJETO

### 2.1 Dados da Obra

Tabela com 2 colunas (rótulo + valor), largura total A4 com margens 2,5 cm:

| Campo | Valor |
|-------|-------|
| Nome da Obra | [dados] |
| Endereço | [dados] |
| Proprietário / Contratante | [dados] |
| Tipo de Uso | [dados] |
| Sistema Estrutural | [do Eberick: eberick-get_report_project_criteria] |
| Número de Pavimentos | [do Eberick] |
| Altura Total | [do Eberick] |

### 2.2 Documentação Analisada

Tabela listando os documentos recebidos:

| Documento | Versão/Revisão | Data |
|-----------|----------------|------|
| Projeto Estrutural Eberick | [dados] | [dados] |
| [Outros documentos] | | |

### 2.3 Normas Aplicáveis

Listar as normas ABNT utilizadas na avaliação (ver `normas-abnt.md`).

---

## 3. CRITÉRIOS E PARÂMETROS DE PROJETO

### 3.1 Parâmetros Gerais

Tabela com os parâmetros extraídos de `eberick-get_report_project_criteria`:

| Parâmetro | Valor Adotado |
|-----------|---------------|
| Classe de resistência do concreto | [dados] |
| Tipo de aço | [dados] |
| Zona bioclimática / agressividade ambiental | [dados] |
| Classe de agressividade ambiental | [dados] |
| Cobrimento nominal | [dados] |
| Categoria de uso (ações variáveis) | [dados] |

### 3.2 Critérios de Modelagem

Descrever os critérios de modelagem identificados no Eberick:
- Tipo de análise (linear, não-linear física/geométrica)
- Consideração de efeitos de 2ª ordem
- Modelo de laje utilizado
- Critérios de vinculação

---

## 4. ESTABILIDADE GLOBAL

### 4.1 Coeficiente γz (Gama-Z)

Tabela com os valores de γz por combinação:

| Combinação de Carregamento | γz | Classificação |
|---|---|---|
| [combinação governante X] | [valor] | [Nós fixos / Nós móveis / Instável] |
| [combinação governante Y] | [valor] | [idem] |

**Critérios de classificação (NBR 6118:2023 item 15.5.3):**
- γz ≤ 1,10: estrutura de nós fixos — efeitos de 2ª ordem globais desprezíveis
- 1,10 < γz ≤ 1,30: estrutura de nós móveis — considerar 2ª ordem global
- γz > 1,30: estrutura instável — projeto não aceito neste critério

### 4.2 Análise P-Delta

Tabela com deslocamentos horizontais por pavimento (dados de `eberick-get_report_p_delta_analysis`):

| Pavimento | Deslocamento 1ª Ordem (mm) | Deslocamento 2ª Ordem (mm) | Amplificação |
|-----------|---------------------------|---------------------------|--------------|
| [pav] | [valor] | [valor] | [%] |

Identificar os pavimentos críticos conforme indicado pelo Eberick.

### 4.3 Avaliação

Parágrafo de avaliação técnica: classificação da estrutura, necessidade de consideração de 2ª ordem global, resultado (CONFORME / NÃO CONFORME) com fundamentação normativa.

---

## 5. INTEGRIDADE DO MODELO COMPUTACIONAL

### 5.1 Resumo do Processamento

Resultado geral do processamento do Eberick (`eberick-get_report_analysis_messages`):
- Status do processamento (sucesso / com erros)
- Total de erros críticos
- Total de avisos

### 5.2 Erros Críticos

Se houver erros, listar em tabela:

| ID | Descrição do Erro | Elemento(s) Afetado(s) | Impacto |
|----|-------------------|----------------------|---------|
| [id] | [descrição] | [elemento] | [crítico/alto/médio] |

Se não houver erros: "Não foram identificados erros críticos de processamento."

### 5.3 Avisos e Alertas

Tabela de avisos relevantes:

| ID | Descrição | Elemento(s) | Classificação |
|----|-----------|-------------|---------------|
| [id] | [descrição] | [elemento] | [relevante / informativo] |

### 5.4 Avaliação

Parágrafo de avaliação: impacto dos erros/avisos na confiabilidade dos resultados, resultado (CONFORME / NÃO CONFORME / COM RESSALVAS).

---

## 6. EFICIÊNCIA E CONSUMO DE MATERIAIS

### 6.1 Resumo Geral

Tabela com totais do projeto (`eberick-get_report_structure_diagnostics`):

| Material | Quantidade Total | Unidade |
|----------|-----------------|---------|
| Aço | [valor] | kg |
| Concreto | [valor] | m³ |
| Forma | [valor] | m² |
| Consumo específico de aço | [valor] | kg/m³ |

### 6.2 Consumo por Tipo de Elemento

Tabela com distribuição por elemento estrutural (pilares, vigas, lajes, fundações se disponível):

| Elemento | Aço (kg) | Concreto (m³) | Consumo (kg/m³) | Avaliação |
|----------|----------|---------------|-----------------|-----------|
| Pilares | | | | |
| Vigas | | | | |
| Lajes | | | | |
| **Total** | | | | |

### 6.3 Consumo por Pavimento

Se disponível, tabela com distribuição por pavimento.

### 6.4 Avaliação

Análise da eficiência estrutural:
- Comparar consumo específico com faixas de referência (80–150 kg/m³ típico)
- Identificar elementos ou pavimentos com consumo atípico
- Avaliar racionalidade estrutural

---

## 7. DIAGNÓSTICO ESTRUTURAL

### 7.1 Pontos Críticos Identificados

Dados de `eberick-get_report_structure_diagnostics`. Tabela com os elementos que requerem atenção:

| Item | Elemento | Descrição | Severidade | Recomendação |
|------|----------|-----------|------------|--------------|
| 1 | [elemento] | [descrição] | Alta / Média / Baixa | [ação recomendada] |

### 7.2 Status por Domínio de Avaliação

Tabela-resumo do diagnóstico:

| Domínio | Status | Observações |
|---------|--------|-------------|
| Estabilidade Global | ✅ Conforme / ⚠️ Atenção / ❌ Não conforme | [obs] |
| Integridade do Modelo | ✅ / ⚠️ / ❌ | [obs] |
| Eficiência de Materiais | ✅ / ⚠️ / ❌ | [obs] |
| Elementos Estruturais | ✅ / ⚠️ / ❌ | [obs] |

---

## 8. CONCLUSÃO E PARECER TÉCNICO

### 8.1 Síntese da Avaliação

Parágrafo de síntese: resumo objetivo dos principais achados da avaliação (3–5 frases).

### 8.2 Parecer Final

Bloco de destaque com o parecer (fundo colorido leve):

```
PARECER: [APROVADO / APROVADO COM RESSALVAS / REPROVADO]
```

Fundamentação do parecer: lista dos principais critérios avaliados e seus resultados.

### 8.3 Ressalvas e Recomendações

Se houver ressalvas, listar em ordem de prioridade:

| Prioridade | Ressalva / Recomendação | Prazo Sugerido |
|------------|------------------------|----------------|
| Alta | [descrição] | Imediato |
| Média | [descrição] | Antes da execução |
| Baixa | [descrição] | Próxima revisão |

### 8.4 Limitações desta Avaliação

Parágrafo padrão:
"A presente Avaliação Técnica de Projeto (ATP) foi realizada com base nos dados e documentos listados na Seção 2, extraídos do modelo computacional Eberick. Aspectos não contemplados no modelo, detalhes executivos, ligações estruturais, e verificações que dependam de dados não fornecidos estão fora do escopo desta avaliação."

---

## 9. ASSINATURAS

Bloco de assinaturas com linhas para:

```
Engenheiro Responsável pelo Projeto:
_________________________________
[NOME]
CREA [NÚMERO]
ART Nº [NÚMERO]


Engenheiro Responsável pela ATP (Revisor):
_________________________________
[NOME]
CREA [NÚMERO]

Local e Data: _________________, _____ de _____________ de _______
```
